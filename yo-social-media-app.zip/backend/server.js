const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/yo', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

// Schema and Model
const postSchema = new mongoose.Schema({
  username: String,
  message: {
    type: String,
    validate: {
      validator: function (v) {
        return v.trim().split(/\s+/).length === 10;
      },
      message: 'Post must be exactly 10 words!'
    }
  },
  createdAt: { type: Date, default: Date.now }
});

const Post = mongoose.model('Post', postSchema);

// Routes
app.post('/posts', async (req, res) => {
  try {
    const post = new Post(req.body);
    await post.save();
    res.status(201).send(post);
  } catch (err) {
    res.status(400).send({ error: err.message });
  }
});

app.get('/posts', async (req, res) => {
  const posts = await Post.find().sort({ createdAt: -1 });
  res.send(posts);
});

// Server
app.listen(3001, () => console.log('Backend running on http://localhost:3001'));
