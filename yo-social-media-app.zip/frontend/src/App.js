import React, { useState, useEffect } from 'react';
import axios from 'axios';

function App() {
  const [username, setUsername] = useState('');
  const [message, setMessage] = useState('');
  const [posts, setPosts] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    axios.get('http://localhost:3001/posts')
      .then(res => setPosts(res.data))
      .catch(err => console.error(err));
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('http://localhost:3001/posts', {
        username,
        message
      });
      setPosts([res.data, ...posts]);
      setMessage('');
      setError('');
    } catch (err) {
      setError(err.response.data.error || 'Something went wrong');
    }
  };

  return (
    <div style={{ maxWidth: 600, margin: 'auto', padding: 20 }}>
      <h1>YO - 10 Word Feelings</h1>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Your name"
          value={username}
          onChange={e => setUsername(e.target.value)}
          required
        />
        <textarea
          placeholder="Exactly 10 words..."
          value={message}
          onChange={e => setMessage(e.target.value)}
          required
        />
        <button type="submit">Post</button>
        {error && <p style={{ color: 'red' }}>{error}</p>}
      </form>

      <ul>
        {posts.map((post, index) => (
          <li key={index}>
            <strong>{post.username}:</strong> {post.message}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
